
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var ground;
var score

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(600,600);
  //Create monkey
  monkey=createSprite(80,500,20,20);
  monkey.addAnimation("monkey",monkey_running);
  monkey.scale=0.2
  //Create floor
  ground=createSprite(300,570,800,20);
  //load obstacle
  //obstacle.addImage("obstacle",obstacleImage);
  
  
  
}


function draw() {
  background("white");
  
  if(keyDown("space") && monkey.y>490) {
    monkey.velocityY = -15;
     
}
  
  monkey.velocityY = monkey.velocityY + 0.6
  monkey.collide(ground);
  
  if(frameCount %180 === 0){
  obstacle=createSprite(610,540,50,50);
  obstacle.velocityX=-7;
  
}
  
  
  
  drawSprites();
}

function End(){
 monkey.setVelocityX=0;
 monkey.setVelocityY=100;
 obstacle.setVelocityX=0;
 

}




